<?php
$konek = mysqli_connect("localhost","root","suru","sharing");
?>